"""
dataset_ingestor
================

Package per il download e la distillazione di eventi GitHub da gharchive.org.
"""