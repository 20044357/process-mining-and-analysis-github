from abc import ABC, abstractmethod
from datetime import datetime, date
from typing import Tuple

from ..domain.types import ProcessHourStatus

class IIngestionUseCase(ABC):
    """Porta di ingresso per avviare i casi d'uso di ingestione dati."""
    
    @abstractmethod
    def process_hour(self, hour_stamp: str, force_reprocess: bool = False) -> Tuple[ProcessHourStatus, int, int, int]:
        pass

    @abstractmethod
    def process_range(self, start_datetime: datetime, end_datetime: datetime, force_reprocess: bool = False) -> Tuple[int, int, int]:
        pass

    @abstractmethod
    def finalize_days(self, days: list[date]) -> None:
        """Verifica se i giorni passati sono completi e avvia la conversione se necessario."""
        pass