"""
Modulo metrics
==============
Contiene i calcoli delle metriche divisi in:
- metrics_from_dataset.py (da parquet)
- metrics_from_api.py (da GitHub API)
"""
