import os
import pickle
from typing import Optional, Any
import pm4py
from pm4py.objects.heuristics_net.obj import HeuristicsNet

from ..domain.interfaces import IModelAnalyzer

class PM4PyModelAnalyzer(IModelAnalyzer):
    """Implementazione di IModelAnalyzer che sa come ispezionare gli oggetti HeuristicsNet di PM4Py."""

    def load_model_from_file(self, file_path: str) -> Optional[Any]:
        try:
            with open(file_path, 'rb') as f:
                return pickle.load(f)
        except (FileNotFoundError, pickle.UnpicklingError) as e:
            print(f"[ModelAnalyzer] ⚠️ Impossibile caricare il modello da {file_path}: {e}")
            return None

    def count_activities(self, model: HeuristicsNet) -> int:
        """CORRETTO: Conta il numero di nodi nell'attributo 'nodes'."""
        if not isinstance(model, HeuristicsNet) or not hasattr(model, 'nodes'):
            return 0
        return len(model.nodes)

    def count_connections(self, model: HeuristicsNet) -> int:
        """CORRETTO: Conta il numero di dipendenze trovate nella 'dependency_matrix'."""
        if not isinstance(model, HeuristicsNet) or not hasattr(model, 'dependency_matrix'):
            return 0
        # Conta solo le dipendenze > 0 (le vere connessioni nel grafo finale)
        return sum(1 for value in model.dependency_matrix.values() if value > 0)

    def has_review_loop(self, model: HeuristicsNet) -> bool:
        """
        CORRETTO: Verifica la presenza di un ciclo di review ispezionando
        la 'dependency_matrix' per dipendenze bidirezionali tra attività chiave.
        """
        if not isinstance(model, HeuristicsNet) or not hasattr(model, 'dependency_matrix'):
            return False
        
        # Definiamo le attività che compongono un ciclo di review
        review_activities = {"IssueCommentEvent", "PullRequestReviewCommentEvent", "PullRequestReviewEvent"}
        correction_activities = {"PullRequestEvent_synchronize", "PushEvent"}

        # La dependency_matrix ha come chiavi oggetti Activity, non stringhe.
        # Dobbiamo iterare e confrontare i loro nomi.
        for (act1, act2), value in model.dependency_matrix.items():
            if value > 0: # C'è un arco da act1 a act2
                
                # Cerchiamo un arco: Review -> Correzione
                if str(act1) in review_activities and str(act2) in correction_activities:
                    # Ora cerchiamo l'arco inverso: Correzione -> Review
                    # Controlliamo se la tupla inversa esiste nella matrice
                    if (act2, act1) in model.dependency_matrix and model.dependency_matrix[(act2, act1)] > 0:
                        print(f"[ModelAnalyzer] Trovato ciclo di review tra '{act1}' e '{act2}'.")
                        return True
        return False

    def get_review_cycle_performance(self, model: HeuristicsNet) -> Optional[float]:
        """
        CORRETTO: Estrae il tempo mediano del ciclo di review
        ispezionando l'attributo 'performance_dfg'.
        """
        if not isinstance(model, HeuristicsNet):
            return None

        # Accediamo all'attributo corretto, come da te indicato.
        perf_dfg = getattr(model, 'performance_dfg', None)
        if not perf_dfg or not isinstance(perf_dfg, dict):
            return None
        
        # Definiamo le attività chiave
        review_activities = {"IssueCommentEvent", "PullRequestReviewCommentEvent", "PullRequestReviewEvent"}
        correction_activities = {"PullRequestEvent_synchronize", "PushEvent"}

        cycle_times_seconds = []
        # Ora iteriamo correttamente sul dizionario perf_dfg
        for (source_activity_obj, target_activity_obj), performance_value in perf_dfg.items():
            source_name = str(source_activity_obj)
            target_name = str(target_activity_obj)

            # Cerchiamo un arco che va da una Review a una Correzione
            if source_name in review_activities and target_name in correction_activities:
                cycle_times_seconds.append(performance_value)
        
        if cycle_times_seconds:
            average_seconds = sum(cycle_times_seconds) / len(cycle_times_seconds)
            return average_seconds / 3600.0
        
        return None