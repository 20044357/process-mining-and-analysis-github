"""
dataset_analysis
================

Package per il process mining da dataset distillato

    - Caricamento lazy dei Parquet
    - Costruzione di log per Mining (handover,...)
    - Metriche da Parquet/API e calcolo SuccessScore
    - Orchestraizone della fase di analysis
"""