# --- Convenzioni di naming per gli artefatti di analisi di processo ---
FREQ_MODEL_SUFFIX = "frequency_model_str.pkl"
PERF_MODEL_SUFFIX = "performance_model_str.pkl"
LOG_FILE_SUFFIX = "filtered_log_str.xes"